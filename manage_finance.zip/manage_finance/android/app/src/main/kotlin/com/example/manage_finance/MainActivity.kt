package com.example.manage_finance

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
