int selectedIndex = 0;
String defaultCurrency = 'RUB';
String defaultLanguage = 'Русский';
