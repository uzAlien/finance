class Constants {
  static String apiKey = "AIzaSyDEjLRGx1tUFP4sycdRqQlYCJQDij58CPo";
  static String projectId = "message-app-3e623";
  static String appId = "1:61392453078:web:b0d94c190686e94f113877";
  static String messagingSenderId = "61392453078";
}
