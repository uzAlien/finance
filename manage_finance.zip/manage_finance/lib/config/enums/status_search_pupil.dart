enum StatusSearchPupil {
  def,
  newPupil,
  inLesson,
}
