enum BlocStatus {
  notInitialized,
  inProgress,
  completed,
  failed,
  connectionFailed,
}
